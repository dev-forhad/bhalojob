<div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">{{__('Add Education')}}</h1>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
        <div class="modal-body">
            
                    <div class="userccount">
                        <div class="formpanel">
                            <div class="formrow">
                                <h3>{{__('Education added successfully')}}</h3>
                            </div>                
                        </div>            
                    </div>
               
        </div>
    </div>
</div>
