<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-bar-chart" aria-hidden="true"></i> <span class="title">Career Levels</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.career.levels') }}" class="nav-link "> <span class="title">List Career Levels</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.career.level') }}" class="nav-link "> <span class="title">Add new Career Level</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.career.levels') }}" class="nav-link "> <span class="title">Sort Career Levels</span> </a> </li>
    </ul>
</li>