<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-level-up" aria-hidden="true"></i> <span class="title">Sliders</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.sliders') }}" class="nav-link ">  <span class="title">List Sliders</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.slider') }}" class="nav-link ">  <span class="title">Add new Slider</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.sliders') }}" class="nav-link "> <span class="title">Sort Sliders</span> </a> </li>
    </ul>
</li>