<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-book" aria-hidden="true"></i> <span class="title">Major Subjects</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.major.subjects') }}" class="nav-link "> <span class="title">List Major Subjects</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.major.subject') }}" class="nav-link "> <span class="title">Add new Major Subject</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('sort.major.subjects') }}" class="nav-link "> <span class="title">Sort Major Subjects</span> </a> </li>
    </ul>
</li>